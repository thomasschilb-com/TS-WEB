﻿<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="en-us" http-equiv="Content-Language">
<title>SYNDICATE.CF | 2019</title>
<link rel="icon" 
      type="image/png" 
      href="favicon.png">
<base target="_self">
<meta name="author" content="Thomas Schilb">
<meta name="publisher" content="Thomas Schilb">
<meta name="copyright" content="(c)2012-2019">
<meta name="description" content="SYNDICATE.CF">
<meta name="robots" content="all, index, follow"> 
<meta name="googlebot" content="all, index, follow"> 
<meta name="pagerank" content="10"> 
<meta name="msnbot" content="all,index,follow"> 
<meta name="revisit" content="2 Days"> 
<meta name="revisit-after" content="2 Days"> 
<meta name="alexa" content="100">
<meta content="News, Links, Software, Games, Tools, Tutorials" name="description">
<link rel="stylesheet" type="text/css" href="style.css" />
<style type="text/css">
.auto-style3 {
	font-size: 8pt;
}
.auto-style4 {
	border-width: 0px;
}
</style>
</head>

<body style="color: #FFFFFF; margin: 0px; background-color: #000000; font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;">
<br><br>
<center>
<img height="100" src="img/title.gif" class="auto-style4"><br><br></center>
<table align="center" cellpadding="0" cellspacing="0" style="width: 690px">
	<tr>
		<td style="border: 1px solid #3F3F3F; text-align: left; background-image: url('img/tab-bg.gif')">
	<table align="center" cellpadding="0" cellspacing="5" style="width: 640px">
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td style="height: 25px; background-color: #333333">&nbsp;Toplist / Vote</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td style="text-align: left">
<a style="color: #3F3F3F;" id="graycol" target="_blank" href="http://www.uscene.net/vote/since">
<img style="color: #3F3F3F;" alt="uscene.net | underground scene network" border="1" src="img/uscene.net.1.gif" width="88" height="31"></a>&nbsp;
<a style="color: #3F3F3F;" id="graycol" target="_blank" href="http://www.linkr.top/since.html">
<img style="color: #3F3F3F;" alt="LinkR.top - Dein Linkverzeichnis für den Underground!" border="1" src="img/linkr.top.1.jpg" width="88" height="31"></a>&nbsp;
<a style="color: #3F3F3F;" id="graycol" target="_blank" href="http://top.nydus.org/vote/4532/">
<img style="color: #3F3F3F;" alt="" border="1" src="img/top.nydus.org.1.gif" width="88" height="31"></a>&nbsp;
<a style="color: #3F3F3F;" id="graycol" target="_blank" href="http://toplist.raidrush.ws/vote/5414/">
<img style="color: #3F3F3F;" alt="Underground / RR.Topliste" src="img/toplist.raidrush.ws.1.gif" border="1" width="88" height="31"></a>
</td>
</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td style="text-align: left; height: 25px; background-color: #333333">&nbsp;Linklist</td>
	</tr>
	<tr>
		<td style="height: 25px"></td>
	</tr>
	<tr>
		<td style="text-align: left">
<a style="color: #3F3F3F;" id="graycol" target="_blank" href="http://area51.to">
<img style="color: #3F3F3F;" alt="AREA51 - Das Underground Linkarchiv" border="1" src="img/area51.1.png" width="88" height="31"></a>&nbsp;
<a style="color: #3F3F3F;" id="graycol" target="_blank" href="http://mafia-linkz.to">
<img style="color: #3F3F3F;" alt="Mafia-Linkz" border="1" src="img/mafia-linkz.to.1.gif" width="88" height="31"></a>&nbsp;
		<a id="graycol" href="http://www.querverweis.net/site/in/3595" style="color: #3F3F3F;" target="_blank">
<img style="color: #3F3F3F;" alt="Querverweis - Underground Links" border="1" src="img/querverweis.1.gif" width="88" height="31"></a>&nbsp;
<a style="color: #3F3F3F;" id="graycol" target="_blank" href="http://bestoflinks.synology.me">
<img style="color: #3F3F3F;" alt="BestOfLinks" src="img/bestoflinks.synology.me.1.gif" border="1" width="88" height="31"></a>&nbsp;
<a style="color: #3F3F3F;" id="graycol" target="_blank" href="http://link-base.org">
<img style="color: #3F3F3F;" alt="LinkBase" src="img/link-base.org.1.gif" border="1" width="88" height="31"></a>&nbsp;
<a style="color: #3F3F3F;" id="graycol" target="_blank" href="http://xlinkz.to">
<img style="color: #3F3F3F;" alt="xLinkz" border="1" src="img/xlinkz.to.1.jpg" width="88" height="31"></a>		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>

	<tr>
		<td style="text-align: left; height: 25px; background-color: #333333">&nbsp;Select Language</td>
	</tr>
			<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td><table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td></td></tr><tr><td width="50%" align="left"><a target="_self" title="DE" href="?to=gate&&lang=de"><img class="fade" src="img/de.gif"></a>&nbsp;&nbsp;/&nbsp;&nbsp;<img title="EN" src="img/us.gif"></a></td><td width="50%" align="right"><i><font color="#3f3f3f"></font></i></td></tr></table>
</td>
	</tr>
</table>
<br>
		</td>
	</tr>

		<tr>
		<td style="width: 690px; text-align: right">
		<span style="color: rgb(63, 63, 63); font-family: &quot;Trebuchet MS&quot;, &quot;Lucida Sans Unicode&quot;, &quot;Lucida Grande&quot;, &quot;Lucida Sans&quot;, Arial, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: -webkit-center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(0, 0, 0); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;" class="auto-style3">
		<a class="auto-style3" href="http://thomasschilb.tk/" style="color: #3f3f3f; text-decoration: none; transition: all 0.3s ease-in; font-family: &quot;Trebuchet MS&quot;, &quot;Lucida Sans Unicode&quot;, &quot;Lucida Grande&quot;, &quot;Lucida Sans&quot;, Arial, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: -webkit-center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(0, 0, 0);" target="_blank">
		<span>&nbsp;</span></a></span><a class="auto-style3" href="https://thomasschilb.net/" style="color: #3f3f3f; text-decoration: none; transition: all 0.3s ease-in; font-family: &quot;Trebuchet MS&quot;, &quot;Lucida Sans Unicode&quot;, &quot;Lucida Grande&quot;, &quot;Lucida Sans&quot;, Arial, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: -webkit-center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(0, 0, 0);" target="_blank">powered by ts</a></td>
	</tr>

	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td style="color: #3F3F3F; text-align: center;"><font color="#530000">&bull;&bull;</font><font color="#990000">&bull;&bull;</font><font color="#FF0000">&bull;</font><font color="#FFFFFF">&bull;</font>&nbsp;<font color="#FFFFFF"><b>[</b></font><a href="main.php?lang=en" style="text-decoration: none" target="_self" target"_self"="">&nbsp;ENTER&nbsp;</a><font color="#FFFFFF"><b>]</b></font>&nbsp;<font color="#FFFFFF">&bull;</font><font color="#FF0000">&bull;</font><font color="#990000">&bull;&bull;</font><font color="#530000">&bull;&bull;</font></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td style="text-align: center">
		 <?php 
	  include 'connect.mysqli.php'; // connect db
	  $ip = $_SERVER['REMOTE_ADDR']; // get ip
	  $test = mysqli_query($con, "SELECT * FROM since WHERE ip='$ip'"); // test if ip is given
	  if(mysqli_num_rows($test) != 1) {
      mysqli_query($con, "INSERT INTO since SET ip='$ip'"); // else make db entry
#	  include ('new-ip-warning.en.html');
      $count = mysqli_num_rows(mysqli_query($con, "SELECT cid FROM syndicate")); // get entry (rows to number)
      $allyearscount = $count + 275613;
	  echo '<br><font color="#808080">No. ' . $allyearscount . '';
      mysqli_close($con); 
	  }
	  
	  else {
      $count = mysqli_num_rows(mysqli_query($con, "SELECT cid FROM syndicate")); // get entry (rows to number)
      $allyearscount = $count + 275613;
	  echo '<br><font color="#808080">No. ' . $allyearscount . '';
	  mysqli_close($con); 
	  }
	  ?>
		 </td>
	</tr>
</table>
<p align="center">&nbsp;</p>
</body>

</html>
