<html>
<head>
<style type="text/css">
@import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap');
.share-tech-mono-regular {
  font-family: "Share Tech Mono", monospace;
  font-weight: 400;
  font-style: normal;
}
font {
  font-family: "Share Tech Mono", monospace;
  font-weight: 400;
  font-style: normal;
  font-size: 23px;
}
a {
	color: #FFFFFF;
	text-decoration: none;
  	transition: 0.3s;
}
a:visited {
	color: #FFFFFF;
}
a:active {
	color: #FFFFFF;
}
a:hover {
	color: #31C8F9;
  	opacity: 1;
}
.auto-style1 {
	text-align: center;
}
.auto-style2 {
	text-align: center;
	font-family: "Share Tech Mono", onospace;
}
.auto-style3 {
	font-family: "Share Tech Mono", onospace;
}
.auto-style4 {
	background-color: #151515;
}
.auto-style5 {
	text-align: right;
	font-family: "Share Tech Mono";
}
.auto-style6 {
	font-family: "Share Tech Mono";
	text-align: left;
	font-size: 23px;
}
.auto-style7 {
	font-size: 50px;
}
.auto-style8 {
	text-align: center;
	font-family: "Share Tech Mono", onospace;
	font-size: 50px;
}
.auto-style9 {
	text-align: center;
	font-family: "Share Tech Mono", onospace;
	font-size: 23px;
}
.auto-style11 {
	text-align: right;
	font-family: "Share Tech Mono";
	font-size: 50px;
}
</style>
<meta content="en-us" http-equiv="Content-Language">
<meta content="IDE, EDITOR, BOOKS, SOURCECODE" name="keywords">
<meta content="ARCHIVE OF CODE" name="description">
<LINK REL="ICON" TYPE="IMAGE/X-ICON" HREF="/favicon.ico">
<link rel="icon" type="image/vnd.microsoft.icon" href="/favicon.ico">
<link rel="shortcut icon" href="/favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
<title>WINWORLDCODE.COM - #1 CODING RESOURCE</title>
<base target="_blank">
</head>

<body style="color: #FFFFFF; background-color: #000000">
<font>
<p class="auto-style2">&nbsp;</p>
<p class="auto-style1">
<img class="auto-style3" height="100" src="wwc.png" width="100"></p>
</font>
<p class="auto-style8">&lt;/WINWORLDCODE&gt;</p>
<p class="auto-style9">&nbsp;</p>
<table align="center" cellpadding="23" cellspacing="0" class="auto-style4" style="width: 100%">
	<tr>
		<td class="auto-style5" style="width: 354px" valign="top">
		<span class="auto-style7">awesome |</span> </td>
		<td class="auto-style6" valign="top">
<font>
		BATCH<br><br>
		<a href="https://www.instructables.com/member/Batchcc/instructables/">
		instructables/batchcc</a></font><br><br>C<br><br>
		<a href="https://github.com/inputsh/awesome-c#readme">
		github/inputsh/awesome-c</a><br><br>C++<br><br>
		<a href="https://github.com/fffaraz/awesome-cpp#readme">
		github/fffaraz/awesome-cpp</a><br><br>CSS<br><br>
		<a href="https://github.com/awesome-css-group/awesome-css#readme">
		github/awesome-css-group/awesome-css</a><br><br>HTML5<br><br>
		<a href="https://github.com/diegocard/awesome-html5#readme">
		github/diegocard/awesome-html5</a><br><br>JAVA<br><br>
		<a href="https://github.com/akullpp/awesome-java#readme">
		github/akullpp/awesome-java</a><br><br>JAVASCRIPT<br>
		<br><a href="https://github.com/sorrycc/awesome-javascript#readme">
		github/sorrycc/awesome-javascript</a><br><br>PHP<br><br>
		<a href="https://github.com/ziadoz/awesome-php#readme">
		github/ziadoz/awesome-php</a><br><br>PYTHON<br><br>
		<a href="https://github.com/vinta/awesome-python#readme">
		github/vinta/awesome-python</a><br><br>SHELL<br><br>
		<a href="https://github.com/alebcay/awesome-shell#readme">
		github/alebcay/awesome-shell</a><br><br>VBA/VB6<br><br>
		<a href="https://github.com/sancarn/awesome-vba#readme">
		github/sancarn/awesome-vba</a><br>&nbsp;<br>
		</td>
	</tr>
	<tr>
		<td class="auto-style11" style="width: 354px" valign="top">
		ts | </td>
		<td class="auto-style6" valign="top">
<font>
		BATCH SCRIPTING<br><br>
				&#8226;&nbsp;IDE &amp; COMPILER &amp; UPX-PACKER<br>&#8226;&nbsp;BOOKS<br>&#8226;&nbsp;SOURCECODE<br><br>DOWNLOAD 
				| <a href="dl/TS-BATCH.ZIP">TS-BATCH.ZIP</a>, 54.4MB<br><br><br>QB64<br>
				<br>
				&#8226;&nbsp;SOURCECODE<br><br>DOWNLOAD | 
		<a href="dl/TS-QB64.ZIP">TS-QB64.ZIP</a>, 5.3MB<br>
				<br>
				<br>VISUAL BASIC 6.0<br><br>
				&#8226;&nbsp;BOOKS<br>&#8226;&nbsp;SOURCECODE<br>&#8226;&nbsp;RUNTIMES<br><br>DOWNLOAD |
				<a href="dl/TS-VB6.ZIP">TS-VB6.ZIP</a>, 133MB<br>&nbsp;</font></td>
	</tr>
</table>
<p class="auto-style9">&copy; 2025 WINWORLDCODE&nbsp;</p>
<p class="auto-style9">NO. <?php include('no.php'); ?></p>
<p class="auto-style9">&nbsp;</p>


