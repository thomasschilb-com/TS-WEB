﻿<html>
<head>
<meta content="en-us" http-equiv="Content-Language">
<meta content="pre, scene, prescene, p2p, web" name="keywords">
<meta content="#1 LINKS IN FILE-SHARING SCENE" name="description">
<meta name="seobility" content="4c122b4b283806ab144e1e68097a2726">
<LINK REL="ICON" TYPE="IMAGE/X-ICON" HREF="favicon.ico">
<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">
<link rel="shortcut icon" href="favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
<title>PRESCENE</title>
<base target="_blank">
<style type="text/css">
@import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap');
.share-tech-mono-regular {
  font-family: "Share Tech Mono", monospace;
  font-weight: 400;
  font-style: normal;
}
a {
	color: #808080;
	text-decoration: none;
}
a:visited {
	color: #808080;
}
a:active {
	color: #808080;
}
a:hover {
	color: #00FF00;
}
.auto-style4 {
	text-align: center;
	font-size: 50px;
}
.auto-style5 {
	text-align: center;
}
.auto-style7 {
	text-align: right;
	background-color: #232323;
}
.auto-style8 {
	font-family: "Share Tech Mono", monospace;
}
.auto-style14 {
	color: #808080;
}
.auto-style10 {
	
}
					 .auto-style25 {
						 font-family: "Share Tech Mono", monospace;
					 }
					 .auto-style26 {
	font-family: "Share Tech Mono", monospace;
	color: #808080;
}
					 .auto-style28 {
						 text-align: center;
						 font-size: 23px;
	font-family: "Share Tech Mono", monospace;
}
					 .auto-style33 {
	color: #FFFFFF;
}
					 .auto-style35 {
	text-align: right;
	font-family: "Share Tech Mono", monospace;
	font-size: 23px;
	color: #FFFFFF;
}
					 .text-center8 {
	color: #808080;
}
.description {
	color: #808080;
}
.p2p-style9 {
	color: #808080;
}
.p2p-style12 {
	color: #00FF00;
}
.p2p-style8 {
	color: #808080;
}
.text-center2 {
	color: #808080;
}
					 .auto-style36 {
	border-width: 0px;
}
					 .auto-style37 {
	font-family: "Share Tech Mono", monospace;
	color: #00FF00;
}
					 .auto-style38 {
	text-align: center;
	background-color: #101010;
}
.auto-style39 {
	text-align: center;
	font-size: 50px;
	background-color: #101010;
}
					 .auto-style42 {
	text-align: center;
	font-family: "Share Tech Mono", monospace;
}
.auto-style43 {
	font-family: "Share Tech Mono", monospace;
}
					 .p2p-style11 {
	color: #00ff00;
}
					 .auto-style44 {
	font-family: "Share Tech Mono", monospace;
	color: #FFFFFF;
}
					 .auto-style45 {
	border-width: 0px;
	font-family: "Share Tech Mono", monospace;
}
					 </style>
</head>

<body style="margin: 0; color: #808080; background-color: #000000">

<table align="center" cellpadding="0" cellspacing="0" style="width: 100%; float: left" class="auto-style10">
	<tr>
		<td class="auto-style28" colspan="2">
		<p>&nbsp;</p><p>
		<a href="./" target="_self" title="Link Us!">
		<img alt="PRESCENE" height="100" longdesc="PRESCENE" src="prescene.png" width="100" class="auto-style36"></p>
		<p class="auto-style33"><span class="p2p-style12">PRE</span><font color="#FFFFFF">SCENE</font></a></p>
		<p>&nbsp;</p>
		</td>
	</tr>
	<tr>
		<td class="auto-style4" valign="top" style="width: 409px">
		<table cellpadding="23" cellspacing="0" style="width: 100%; float: left">
			<tr>
				<td class="auto-style35">p2p |</td>
			</tr>
		</table>
		</td>
		<td class="auto-style5">
		<table align="center" cellpadding="23" cellspacing="0" style="width: 100%; float: left">
			<tr>
				<td class="auto-style14" valign="top">
<span class="auto-style25"><span class="auto-style33">EMULE</span><br><br>CLIENT 
[1]<br><br></span><span class="description"><span class="p2p-style9">
<span class="auto-style43">
				<a href="https://sourceforge.net/projects/amule/files/aMule/2.3.1/">aMule</a></span><span class="p2p-style12"><span class="auto-style43">
*</span></span></span></span><p class="auto-style8">
				<span class="auto-style43"><span class="auto-style25">
				SERVER.MET [5]<br>
				</span><br><span class="description"><span class="p2p-style9">
				<span class="p2p-style12">
						<a href="https://edk.peerates.net/servers/online-servers-list">
						edk.peerates.net</a><br>
<a href="http://upd.emule-security.org/server.met">
						upd.emule-security.org</a> *<br>
						<a href="http://peerates.net/servers.php">peerates.net</a><br>
						<a href="http://www.gruk.org/server.met">gruk.org</a>
						<a href="http://www.gruk.org/server.met.gz">gzip</a><br><a href="http://shortypower.org/server.met">
						shortypower.org</a></span></span></span></span><br>
				<span class="auto-style25">
				<br>NODES.DAT [4]<br><br>
						<span class="p2p-style12">
						<span class="description"><span class="p2p-style9">
						<a href="http://upd.emule-security.org/nodes.dat">
						emule-security.org</a><br>
						<a href="http://www.nodes-dat.com/">nodes-dat.com</a></span></span><span class="auto-style43"> *</span><span class="p2p-style9"><span class="description"><br>
						<a href="http://server-met.emulefuture.de/download.php?file=nodes.dat">
						emulefuture.de</a><br>
<a href="http://download.tuxfamily.org/technosalad/utils/nodes.dat">
tuxfamily.org</a></span></span></span></span><br><br>SITE 
				[7]<br>
				<br><span class="description"><span class="p2p-style9"><span class="p2p-style12">
						<a href="http://wiki.amule.org/wiki/Keep_a_safe_list_of_servers">
						amule.org</a><br>
						<a href="http://www.emule-security.org/">
						emule-security.org</a><br>
						<a href="https://emulefuture.de/">emulefuture.de</a><br>
				<a href="http://www.emule-web.de/board/">
						emule-web.de</a><br>
						<a href="http://www.emule.nu/">emule.nu</a><br>
<a href="https://goldesel.to/">goldesel.to</a><span class="auto-style25"><span class="auto-style43"> *</span></span><br>
						<a href="https://sharethefiles.com/forum/">
						sharethefiles.com</a></span></span></span></p>
				<p class="auto-style8">
				&nbsp;</p>
				<p class="auto-style8">
				<span class="auto-style33">FOPNU</span><br><br>CLIENT [2]<br><br>
				<a href="https://www.fopnu.com/download/">fopnu/download</a><br>
				<a href="https://www.fopnu.com/download/portable.html">
				fopnu/portable</a><br><br>SITE [3]<br><br>
				<a href="https://support.fopnu.com/ManualPeer">SetupYourIP</a><br>
				<br><span class="p2p-style9"><span class="description">
				<span class="p2p-style12"><span class="p2p-style11">
				<a href="https://api.ipify.org/">GetIPv4</a><br>
				<a href="https://api6.ipify.org/">GetIPv6</a></span></span></span></span></p>
				<p class="auto-style8">
				&nbsp;</p>
				<p class="auto-style8">
				<span class="auto-style43"><span class="auto-style33">TORRENT</span><br>
				<br>CLIENT [1]<br><br></span>
				<span class="p2p-style9"><span class="description">
				<span class="p2p-style12">

						<span class="p2p-style8">
						<a href="https://www.tixati.com/">
				<span class="auto-style43">Tixati</span><span class="auto-style37"> *</span></a></span></span></span></span><br></p>
				<p class="auto-style8">
				<span class="auto-style43"><span class="auto-style25">
				SITE [10]<br><br>
				</span></span><span class="p2p-style9"><span class="description"><span class="p2p-style12">

						<font >

						<span class="p2p-style8">
						<span class="auto-style43">
						<a href="https://bitcq.com" style="text-decoration: none">bitcq.com</a><br>
<a href="https://bittorrent.am/">bittorrent.am</a><br>
<a href="https://idope.se/">idope.se</a><br>
						<a href="https://www.limetorrents.info/">
limetorrents.info</a><br>
						<a href="http://www.magnetdl.com/" style="text-decoration: none">
magnetdl.com</a><br>
						<span class="text-center2"><a href="http://rutracker.nl/">rutracker.nl</a></span></span></span><span class="auto-style43">
						*<span class="p2p-style8"><br>
<a href="https://thepiratebay.org/" style="text-decoration: none">thepiratebay.org</a><br>
						</span>
						</span>
						</font>

						<span class="auto-style43">

						<span class="p2p-style8">
						<font  color="#FF0000">
						<a href="https://torrents.io/">
						torrents.io</a></font><br>
<a href="https://tvunderground.org.ru/index.php">tvunderground.org.ru</a><br>
<a href="https://zooqle.com/">zooqle.com</a></span></span></span></span></span></p>
				<p class="auto-style8">
				<span class="auto-style43">TRACKERLIST
				[4]<br>
</span><br><span class="p2p-style9"><span class="description"><font > <span class="p2p-style12"><span class="p2p-style8">
<span class="auto-style26"><a href="https://newtrackon.com/list">newtrackon.com</a></span></span><span class="auto-style43">
*</span><span class="text-center2"><span class="auto-style26"><br>
<a href="https://www.torrenttrackerlist.com/torrent-tracker-list/">
torrenttrackerlist.com</a><br>
<a href="https://tinytorrent.net/best-torrent-tracker-list-updated/">
tinytorrent.net</a><br><a href="https://trackerslist.com">trackerslist.com</a></span></span></span></font></span></span><br></p>
				</span>
				</td>
			</tr>
		</table>
		</td>
	</tr>
<tr>
		<td class="auto-style39" valign="top" style="width: 409px">
		<table cellpadding="23" cellspacing="0" style="width: 100%; float: left">
			<tr>
				<td class="auto-style35">web |</td>
			</tr>
		</table>
		</td>
		<td class="auto-style38">
		<table align="center" cellpadding="23" cellspacing="0" style="width: 100%; float: left">
			<tr>
				<td class="auto-style14" valign="top">
				<span class="auto-style25">
<p class="auto-style8">
<span class="auto-style33">TOR</span><br><br><span class="auto-style25">BROWSER 
[1]</span><br><br>
<a href="https://sourceforge.net/projects/tor-browser.mirror/" target="_blank">Tor Browser</a><span class="p2p-style9"><span class="description"><span class="p2p-style12"><span class="p2p-style8"><a href="https://www.tixati.com/"><span class="auto-style37"> *</span></a></span></span></span></span><br></p>
				<p class="auto-style43">
				&nbsp;</p>
				<p class="auto-style43">
				<span class="auto-style25">
				<span class="auto-style33">AWESOME</span><br><br>SITE [1]<br><br>
				<a href="https://github.com/topics/awesome" target="_blank">
				Awesome/GitHub</a><span class="p2p-style9"><span class="description"><span class="p2p-style12"><span class="p2p-style8"><a href="https://www.tixati.com/"><span class="auto-style37"> *</span></a></span></span></span></span></span></p>
				<p class="auto-style43">
				&nbsp;</p>
				<p class="auto-style43">
				<span class="auto-style33">PREDB</span><br><br>SITE [14]<br><br><a href="http://m2v.ru/">m2v.ru</a><br>
				<a href="https://ngp.re/index.php">ngp.re</a><span class="auto-style25"><span class="p2p-style12"> 
*</span></span><br>
						<a href="http://pre.corrupt-net.org">pre.corrupt-net.org</a><br>
						<a href="http://predb.me">predb.me</a><br>
						<a href="https://predb.net/" target="_blank">predb.net</a><span class="p2p-style12"> 
*</span><br><br><a href="http://predb.org">
		predb.org</a><br><a href="http://predb.pw">predb.pw</a><br>
						<a href="http://rmz.cr/">rmz.cr</a><br>
						<a href="https://rslinks.org/">rslinks.org</a><br>
						<a href="https://www.scnsrc.me">scnsrc.me</a><br><a href="http://srrdb.com">srrdb.com</a><br>
						<a href="https://www.srrxxx.com/">srrxxx.com</a><br>
						<a href="https://tryzonet.xyz/">tryzonet.xyz</a><br>
						<a href="https://www.xrel.to/">xrel.to</a></p>
				</span>
				</td>
			</tr>
		</table>
		</td>
	</tr>
<tr>
		<td class="auto-style4" valign="top" style="width: 409px">
		<table cellpadding="23" cellspacing="0" style="width: 100%; float: left">
			<tr>
				<td class="auto-style35">info |</td>
			</tr>
		</table>
		</td>
		<td class="auto-style5">
		<table align="center" cellpadding="23" cellspacing="0" style="width: 100%; float: left">
			<tr>
				<td class="auto-style14" valign="top">
				<span class="auto-style25"><p class="auto-style8">
				<span class="auto-style43"><span class="auto-style33">#1 SCENE LINKS IN FILE-SHARING!<br>
				</span>
				<br>WE ARE LISTING'S OF THE MOST POPULAR<br>APPS &amp; SITE'S ON THE 
				WEB.<br><br>OUR LINKS &amp; CONTENT WERE TAKEN<br>WITH THE UTMOST CARE AND<br>ONLY FROM LEGAL SOURCE'S LIKE:<br><br>GOOGLE, BING, DUCKDUCKGO, 
				ARCHIVE.ORG, ETC.<br>
				<br>THIS IS A TINY FORK OF THE SCENE. WE DO NOT<br>TAKE LIABILITY 
				FOR ANY INJURIES OR DAMAGES,<br>SO BE AWARE OF WHAT YOU ARE 
				DOING!<br><br>IN TOTAL THERE ARE TOP 50+ LINKS SO FAR.<br><br>
				LAST UPDATED: 2025/03</span><br class="auto-style43"></p>
				</span>
				</td>
			</tr>
		</table>
		</td>
	</tr>
<tr>
		<td class="auto-style39" valign="top" style="width: 409px">
		<table cellpadding="23" cellspacing="0" style="width: 100%; float: left">
			<tr>
				<td class="auto-style35">banner |</td>
			</tr>
		</table>
		</td>
		<td class="auto-style38">
		<table align="center" cellpadding="23" cellspacing="0" style="width: 100%; float: left">
			<tr>
				<td class="auto-style14" valign="top">
				<span class="auto-style25"><p class="auto-style8">
				<span class="auto-style43"><a href="https://prescene.us.to">
				<img src="prescene-banner-large.png" class="auto-style36"></a><br>
				468x60px<br><br><a href="https://prescene.us.to">
				<img src="prescene-banner-small.png" class="auto-style36"></a><br>
				88x31px</span><br class="auto-style43"></p>
				</span><span class="auto-style8">
				<p class="auto-style26">[banner:png]</p>
				</span>
				</td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td class="auto-style7" colspan="2">
		<table cellpadding="23" cellspacing="0" style="width: 100%; float: left" class="auto-style14">
			<tr>
				<td valign="top" style="width: 66px" class="auto-style43">
				<span class="auto-style33">Index</span><br>
				<br>p2p<br>web<br><br>info<br>banner</td>
				<td valign="top" style="width: 153px" class="auto-style8">
				<span class="auto-style43">
				<span class="auto-style33">Domain/Proxy</span><br><br>
				<a target="_self" href="https://prescene.click">prescene.click</a><br>
				<a target="_self" href="https://prescene.link">prescene.link</a><br>
				<a target="_self" href="https://prescene.tech">prescene.tech</a><br>
				<br><span class="auto-style33">Darqnet/VPN</span><br><br>
				<a target="_self" href="https://prescene.groups.id">prescene.groups.id</a><br>
				<a href="https://prescene.us.to" target="_self">prescene.us.to</a></span><br><br class="auto-style43"></td>
				<td valign="top">
				<font class="ps2-style6">
				<span class="ps1-style8"> 
				<span class="auto-style44">Vote</span><br class="auto-style43">
				<br class="auto-style43">
				<a href="http://top.nydus.org/vote/4898/" target="_blank">
<img id="graycol0" src="nydus_butt_3.png" alt="Underground Topliste - Nydus" class="auto-style45" align="top" /></a></span></font><br class="auto-style43">
				<br class="auto-style43">
				<a href="http://toplist.raidrush.ws/vote/6412/" target="_blank">
				<img src="rr_butt_4.png" class="auto-style36"></a><br class="auto-style43"></td>
			</tr>
		</table>
		</td>
	</tr>
</table>
<p class="auto-style43">&nbsp;</p>
<p class="auto-style42">&nbsp;© 2025 PRESCENE</p>
<p class="auto-style42"><?php include('no.php');?></p>
<p class="auto-style42">&nbsp;</p>


</html>